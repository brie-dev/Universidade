package trabalho;

//classe "filha" de moeda
public class Euro extends Moeda{
	
	//dando um valor
	public Euro(double valorInicial) {
		this.valor = valorInicial;
	}
		
	//mostra o valor
	@Override
	public void info() {
		System.out.println("Euro - " + valor);
	}
	
	//converte o valor para real
	@Override
	public double converter() {
		return this.valor * 6.09;
	}
	
	public boolean equals(Object objeto) {
		if (this.getClass() != objeto.getClass()) {
			return false;
		}
		
		Euro objetoDeEuro = (Euro) objeto;
		
		if (this.valor != objetoDeEuro.valor) {
			return false;
		}
		return true;
	}
	
}
