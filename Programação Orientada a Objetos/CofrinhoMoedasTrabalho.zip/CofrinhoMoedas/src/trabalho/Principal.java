package trabalho;

public class Principal {
	
	public static void main(String[] args) {
		MenuCofrinho menu = new MenuCofrinho();
		menu.menu();
	}
		
}
