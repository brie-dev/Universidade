package trabalho;

abstract public class Moeda {
	
	protected double valor;
	
	//metodos
	public abstract void info();
	public abstract double converter();
}
