package trabalho;

//classe "filha" de moeda
public class Real extends Moeda{
	
	//dando um valor
	public Real(double valorInicial) {
		this.valor = valorInicial;
	}
	
	//mostra o valor
	@Override
	public void info() {
		System.out.println("Real - " + valor);
	}
	
	//converte o valor para o real
	@Override
	public double converter() {
		return this.valor;
	}

	public boolean equals(Object objeto) {
		if (this.getClass() != objeto.getClass()) {
			return false;
		}
		
		Real objetoDeReal = (Real) objeto;
		
		if (this.valor != objetoDeReal.valor) {
			return false;
		}
		return true;
	}
}
