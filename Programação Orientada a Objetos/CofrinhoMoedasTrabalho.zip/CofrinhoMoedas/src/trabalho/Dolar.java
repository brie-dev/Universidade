package trabalho;

//classe "filha" de moeda
public class Dolar extends Moeda{
	
	//dando um valor
	public Dolar(double valorInicial) {
		this.valor = valorInicial;
	}
	
	//mostra o valor	
	@Override
	public void info() {
		System.out.println("Dolar - " + valor);
	}
	
	//converte o valor para o real
	@Override
	public double converter() {
		return this.valor * 5.81;
	}
	
	public boolean equals(Object objeto) {
		if (this.getClass() != objeto.getClass()) {
			return false;
		}
		
		Dolar objetoDeDolar = (Dolar) objeto;
		
		if (this.valor != objetoDeDolar.valor) {
			return false;
		}
		return true;
	}

}
