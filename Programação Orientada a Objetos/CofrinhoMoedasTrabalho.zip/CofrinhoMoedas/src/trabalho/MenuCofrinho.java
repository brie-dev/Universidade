package trabalho;

import java.util.Scanner;

public class MenuCofrinho {
	
	//obter dados do usuario
	private Scanner teclado;
	private Cofrinho cofrinho;
	
	public MenuCofrinho() {
		teclado = new Scanner(System.in);
		cofrinho = new Cofrinho();
	}
	//exibir o menu
	public void menu() {
		System.out.println("COFRINHO:");
		System.out.println("1 - Adicionar moeda: ");
		System.out.println("2 - Remover moeda: ");
		System.out.println("3 - Listar moedas: ");
		System.out.println("4 - Calcular o valor total convertido para real: ");
		System.out.println("0 - Encerrar");
		
		//guardar o valor em uma variavel
		String opcaoEscolhida = teclado.next();
		
		//sistema do menu
		switch (opcaoEscolhida) {
		//encerrar o programa
		case "0":
			System.out.println("Programa encerrado!");
			break;
		//adicionar moeda
		case "1":
			System.out.println("Escolha a moeda: ");
			System.out.println("1 - Real: ");
			System.out.println("2 - Dólar: ");
			System.out.println("3 - Euro: ");
			int opcaoMoeda = teclado.nextInt();
			
			System.out.println("Digite o valor: ");
			String valorMoeda = teclado.next();
			valorMoeda = valorMoeda.replace(",", ".");
			double valorDaMoeda = Double.valueOf(valorMoeda);
			
			//adicionando moeda/valor escolhido
			if (opcaoMoeda == 1) {
				Real moeda = new Real(valorDaMoeda);
				cofrinho.adicionar(moeda);
			} else if (opcaoMoeda == 2) {
				Dolar moeda = new Dolar(valorDaMoeda);
				cofrinho.adicionar(moeda);
			} else if (opcaoMoeda == 3) {
				Euro moeda = new Euro(valorDaMoeda);
				cofrinho.adicionar(moeda);
			} else {
				System.out.println("Opção indisponível!");
			}
			
			menu();
			break;
		//remover moeda
		case "2":
			System.out.println("Escolha a moeda: ");
			System.out.println("1 - Real: ");
			System.out.println("2 - Dólar: ");
			System.out.println("3 - Euro: ");
			int opcaoMoeda1 = teclado.nextInt();
			
			System.out.println("Digite o valor: ");
			String valorMoeda1 = teclado.next();
			valorMoeda1 = valorMoeda1.replace(",", ".");
			double valorDaMoeda1 = Double.valueOf(valorMoeda1);
			
			//removendo moeda/valor escolhido
			if (opcaoMoeda1 == 1) {
				Real moeda = new Real(valorDaMoeda1);
				cofrinho.remover(moeda);
			} else if (opcaoMoeda1 == 2) {
				Dolar moeda = new Dolar(valorDaMoeda1);
				cofrinho.remover(moeda);
			} else if (opcaoMoeda1 == 3) {
				Euro moeda = new Euro(valorDaMoeda1);
				cofrinho.remover(moeda);
			} else {
				System.out.println("Opção indisponível!");
			}
			
			menu();
			Moeda moeda = null;
			cofrinho.remover(moeda);
			break;
		//listar moeda
		case "3":
			cofrinho.listagemMoedas();
			menu();
			break;
		//converter moedas para real
		case "4":
			double valorTotalReal = cofrinho.totalConvertido();
			System.out.printf("O valor total convertido para real? %.2f\n", valorTotalReal);
			menu();
			break;
		//numero que nao faça parte do sistema do menu
		default:
			System.out.println("Opção inválida!");
			menu();
			break;
		}
	}

}
